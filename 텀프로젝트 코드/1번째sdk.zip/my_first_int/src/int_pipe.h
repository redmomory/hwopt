#define OFMAP_BASE_C2   0x25000000
#define OFMAP_BASE_C4   (OFMAP_BASE_C2 + (E_C2*F_C2*M_C2) * sizeof(int))
#define IFMAP_BASE_C2   (OFMAP_BASE_C4 + (E_C4*F_C4*M_C4) * sizeof(int))
#define IFMAP_BASE_C4   (IFMAP_BASE_C2 + (H_C2*W_C2*C_C2) * sizeof(int))
#define FMAP_BASE_C2   (IFMAP_BASE_C4 + (H_C4*W_C4*C_C4) * sizeof(int))
#define FMAP_BASE_C4   (FMAP_BASE_C2 + (R_C2*S_C2*C_C2*M_C2) * sizeof(int))

#define OFMAP_BASE_C3   0x1B500000
#define OFMAP_BASE_C5   (OFMAP_BASE_C3 + (E_C3*F_C3*M_C3) * sizeof(int))
#define IFMAP_BASE_C3   (OFMAP_BASE_C5 + (E_C5*F_C5*M_C5) * sizeof(int))
#define IFMAP_BASE_C5   (IFMAP_BASE_C3 + (H_C3*W_C3*C_C3) * sizeof(int))
#define FMAP_BASE_C3   (IFMAP_BASE_C5 + (H_C5*W_C5*C_C5) * sizeof(int))
#define FMAP_BASE_C5   (FMAP_BASE_C3 + (R_C3*S_C3*C_C3*M_C3) * sizeof(int))

/*DMA_DEVICE*/
XAxiDma DMA0;
XAxiDma DMA1;
XAxiDma DMA2;
XAxiDma DMA3;
XAxiDma DMA4;
XAxiDma DMA5;
XAxiDma DMA6;
XAxiDma DMA7;
XAxiDma DMA8;
XAxiDma DMA9;
XAxiDma DMA10;
XAxiDma DMA11;
#include "setDMA.h"
/* Interrupt Controller Instance */
XScuGic scugic;

/////////////////////////////////////// Convolution 2 Variable
volatile int dma0 = 0;
volatile int dma1 = 0;
extern volatile int dma2 = 0;
volatile int conv2 = 0;
volatile int conv2_c = 0;
volatile int conv2_m = 0;
volatile int conv2_g = 0;
/////////////////////////////////////// Convolution 3 Variable
volatile int dma3 = 0;
volatile int dma4 = 0;
extern volatile int dma5 = 0;
volatile int conv3 = 0;
volatile int conv3_c = 0;
volatile int conv3_m = 0;
/////////////////////////////////////// Convolution 4 Variable
volatile int dma6 = 0;
volatile int dma7 = 0;
extern volatile int dma8 = 0;
volatile int conv4 = 0;
volatile int conv4_c = 0;
volatile int conv4_m = 0;
volatile int conv4_g = 0;
/////////////////////////////////////// Convolution 5 Variable
volatile int dma9 = 0;
volatile int dma10 = 0;
extern volatile int dma11 = 0;
volatile int conv5 = 0;
volatile int conv5_c = 0;
volatile int conv5_m = 0;
volatile int conv5_g = 0;
/*
DMA0 DMA3 DMA6 DMA9 �� �־ �۵��� �� ����.
*/
static void DMA0_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
			if (conv2_c == 47 && conv2_m == 63) // ���� ����
			{
				DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2 + 27 * 27 * 4 * sizeof(int)*(conv2_m));
				DMA_read(&DMA2, 27 * 27 * 4 * sizeof(int));
				dma2 = 1;
				XAxiDma_IntrDisable(&DMA0, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA1, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA2, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
				xil_printf(" Conv2_END & CONV 5 START \n\r");
				///////////////////////////////////////////// CONVOLUTION5 START//////////////////////////////////////////////
				XAxiDma_IntrEnable(&DMA9, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrEnable(&DMA10, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrEnable(&DMA11, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);

				DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5 + (13 * 13) * 4 * sizeof(int)*conv5_m);
				DMA_read(&DMA11, 13 * 13 * 4 * sizeof(int));
				DMA_TADDR_setup(&DMA9, IFMAP_BASE_C5 + (15)*(15) * 2 * sizeof(int)*conv5_c);
				DMA_write(&DMA9, (15)*(15) * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA10, FMAP_BASE_C5 + (4 * 2 * 3 * 3 * sizeof(int)*conv5));
				DMA_write(&DMA10, 4 * 2 * 3 * 3 * sizeof(int));
			}
			else
			{
				conv2++;
				conv2_c = conv2_g * 24 + (conv2 % 24);
				if (conv2_c == 0 || conv2_c == 24)
				{
					DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2 + 27 * 27 * 4 * sizeof(int)*(conv2_m));
					DMA_read(&DMA2, 27 * 27 * 4 * sizeof(int));
					conv2_m++;
					if (conv2_m == 32)
					{
						conv2_c = 24;
						conv2_g = 1;
					}
				}
				DMA_TADDR_setup(&DMA0, IFMAP_BASE_C2 + 31 * 31 * 2 * sizeof(int)*conv2_c);
				DMA_write(&DMA0, 31 * 31 * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA1, FMAP_BASE_C2 + (4 * 2 * 5 * 5 * sizeof(int)*conv2));
				DMA_write(&DMA1, 4 * 2 * 5 * 5 * sizeof(int));
			}
	}
}
static void DMA1_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		return;
	}
}
static void DMA2_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	/* Read pending interrupts */
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DEVICE_TO_DMA);
	/* Acknowledge pending interrupts */
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DEVICE_TO_DMA);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) {
		return;
	}
}

static void DMA3_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { 
			if (conv3_c == 127 && conv3_m == 95)
			{
				DMA_RADDR_setup(&DMA5, OFMAP_BASE_C3 + (13 * 13) * 4 * sizeof(int)*conv3_m);
				DMA_read(&DMA5, 13 * 13 * 4 * sizeof(int));
				dma5 = 1;
				XAxiDma_IntrDisable(&DMA3, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA4, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA5, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
				//xil_printf("Conv3_End & Conv4_Start \n\r");
				XAxiDma_IntrEnable(&DMA6, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrEnable(&DMA7, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrEnable(&DMA8, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
				DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4 + (13 * 13) * 4 * sizeof(int)*conv4_m);
				DMA_read(&DMA8, 13 * 13 * 4 * sizeof(int));
				DMA_TADDR_setup(&DMA6, IFMAP_BASE_C4 + (15)*(15) * 2 * sizeof(int)*conv4_c);
				DMA_write(&DMA6, (15)*(15) * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA7, FMAP_BASE_C4 + (4 * 2 * 3 * 3 * sizeof(int)*conv4));
				DMA_write(&DMA7, 4 * 2 * 3 * 3 * sizeof(int));
			}
			else
			{
				conv3++;
				conv3_c = (conv3 % 128);
				if (conv3_c == 0)
				{
					DMA_RADDR_setup(&DMA5, OFMAP_BASE_C3 + (13 * 13) * 4 * sizeof(int)*conv3_m);
					DMA_read(&DMA5, 13 * 13 * 4 * sizeof(int));
					conv3_m++;
				}
				DMA_TADDR_setup(&DMA3, IFMAP_BASE_C3 + (15)*(15) * 2 * sizeof(int)*conv3_c);
				DMA_write(&DMA3, (15)*(15) * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA4, FMAP_BASE_C3 + (4 * 2 * 3 * 3 * sizeof(int)*conv3));
				DMA_write(&DMA4, 4 * 2 * 3 * 3 * sizeof(int));
			}
	}
}
static void DMA4_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) {
		return;
	}
}
static void DMA5_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) {
		return;
	}
}

static void DMA6_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
			if (conv4_c == 191 && conv4_m == 95)
			{
				conv4_m++;
				DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4 + 13 * 13 * 4 * sizeof(int)*(conv4_m));
				DMA_read(&DMA8, 13 * 13 * 4 * sizeof(int));
				//xil_printf("Lable4 End! \n\r");
				XAxiDma_IntrDisable(&DMA6, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA7, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA8, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
			}
			else
			{
				conv4++;
				conv4_c = conv4_g * 96 + (conv4 % 96);
				if (conv4_c == 0 || conv4_c == 96)
				{
					DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4 + 13 * 13 * 4 * sizeof(int)*(conv4_m));
					DMA_read(&DMA8, 13 * 13 * 4 * sizeof(int));
					conv4_m++;
					if (conv4_m == 48)
					{
						conv4_c = 96;
						conv4_g = 1;
					}
				}
				DMA_TADDR_setup(&DMA6, IFMAP_BASE_C4 + 15 * 15 * 2 * sizeof(int)*conv4_c);
				DMA_write(&DMA6, 15 * 15 * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA7, FMAP_BASE_C4 + (4 * 2 * 3 * 3 * sizeof(int)*conv4));
				DMA_write(&DMA7, 4 * 2 * 3 * 3 * sizeof(int));
			}
		}	
}
static void DMA7_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		return;
	}
}
static void DMA8_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		return;
	}
}

static void DMA9_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
			if (conv5_c == 191 && conv5_m == 63)
			{
				conv5_m++;
				DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5 + 13 * 13 * 4 * sizeof(int)*(conv5_m));
				DMA_read(&DMA11, 13 * 13 * 4 * sizeof(int));
				dma11 = 1;
				//xil_printf("Lable5 End! \n\r");
				XAxiDma_IntrDisable(&DMA9, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA10, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
				XAxiDma_IntrDisable(&DMA11, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
			}
			else
			{
				conv5++;
				conv5_c = conv5_g * 96 + (conv5 % 96);
				if (conv5_c == 0 || conv5_c == 96)
				{
					DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5 + 13 * 13 * 4 * sizeof(int)*(conv5_m));
					DMA_read(&DMA11, 13 * 13 * 4 * sizeof(int));
					conv5_m++;
					if (conv5_m == 32)
					{
						conv5_c = 96;
						conv5_g = 1;
					}
				}
				DMA_TADDR_setup(&DMA9, IFMAP_BASE_C5 + 15 * 15 * 2 * sizeof(int)*conv5_c);
				DMA_write(&DMA9, 15 * 15 * 2 * sizeof(int));
				DMA_TADDR_setup(&DMA10, FMAP_BASE_C5 + (4 * 2 * 3 * 3 * sizeof(int)*conv5));
				DMA_write(&DMA10, 4 * 2 * 3 * 3 * sizeof(int));
			}
		}	
}
static void DMA10_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		return;
	}
}
static void DMA11_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		return;
	}
}

static int DMA_connect_interrupt(void)
{
	//This functions sets up the interrupt on the Arm
	int status;
	XScuGic_Config *scugic_cfg = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);
	if (scugic_cfg == NULL) {
		xil_printf("Interrupt Configuration Lookup Failed\n\r");
		return XST_FAILURE;
	}

	status = XScuGic_CfgInitialize(&scugic, scugic_cfg, scugic_cfg->CpuBaseAddress);
	if (status != XST_SUCCESS) {
		xil_printf("ScuGic Initialize Failed\n\r");
		return status;
	}

	status = XScuGic_SelfTest(&scugic);
	if (status != XST_SUCCESS) {
		xil_printf("ScuGic selfTest Failed\n\r");
		return status;
	}
	//	XScuGic_SetPriorityTriggerType(&scugic, XPAR_FABRIC_AXI_DMA_3_MM2S_INTROUT_INTR, 0xA0, 0x3);

	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA0_isr, &DMA0);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA1_isr, &DMA1);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR, (Xil_InterruptHandler)DMA2_isr, &DMA2);
	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_3_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA3_isr, &DMA3);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_4_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA4_isr, &DMA4);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_5_S2MM_INTROUT_INTR, (Xil_InterruptHandler)DMA5_isr, &DMA5);
	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_6_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA6_isr, &DMA6);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_7_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA7_isr, &DMA7);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_8_S2MM_INTROUT_INTR, (Xil_InterruptHandler)DMA8_isr, &DMA8);
	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_9_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA9_isr, &DMA9);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_10_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA10_isr, &DMA10);
	//XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_11_S2MM_INTROUT_INTR, (Xil_InterruptHandler)DMA11_isr, &DMA11);

	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR);
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_3_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_4_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_5_S2MM_INTROUT_INTR);
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_6_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_7_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_8_S2MM_INTROUT_INTR);
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_9_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_10_MM2S_INTROUT_INTR);
	//XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_11_S2MM_INTROUT_INTR);

	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler, &scugic);
	Xil_ExceptionEnable();
	return XST_SUCCESS;
}
void Start_ISR()
{
	Xil_DCacheFlushRange(IFMAP_BASE_C2, sizeof(int)*H_C2*W_C2*C_C2);
	Xil_DCacheFlushRange(FMAP_BASE_C2, sizeof(int)*R_C2*S_C2*C_C2*M_C2);
	Xil_DCacheFlushRange(IFMAP_BASE_C3, sizeof(int)*H_C3*W_C3*C_C3);
	Xil_DCacheFlushRange(FMAP_BASE_C3, sizeof(int)*R_C3*S_C3*C_C3*M_C3);
	Xil_DCacheFlushRange(IFMAP_BASE_C4, sizeof(int)*H_C4*W_C4*C_C4);
	Xil_DCacheFlushRange(FMAP_BASE_C4, sizeof(int)*R_C4*S_C4*C_C4*M_C4);
	Xil_DCacheFlushRange(IFMAP_BASE_C5, sizeof(int)*H_C5*W_C5*C_C5);
	Xil_DCacheFlushRange(FMAP_BASE_C5, sizeof(int)*R_C5*S_C5*C_C5*M_C5);

	DMA_preset0(XPAR_AXI_DMA_0_DEVICE_ID);
	DMA_preset1(XPAR_AXI_DMA_1_DEVICE_ID);
	DMA_preset2(XPAR_AXI_DMA_2_DEVICE_ID);
	DMA_preset3(XPAR_AXI_DMA_3_DEVICE_ID);
	DMA_preset4(XPAR_AXI_DMA_4_DEVICE_ID);
	DMA_preset5(XPAR_AXI_DMA_5_DEVICE_ID);
	DMA_preset6(XPAR_AXI_DMA_6_DEVICE_ID);
	DMA_preset7(XPAR_AXI_DMA_7_DEVICE_ID);
	DMA_preset8(XPAR_AXI_DMA_8_DEVICE_ID);
	DMA_preset9(XPAR_AXI_DMA_9_DEVICE_ID);
	DMA_preset10(XPAR_AXI_DMA_10_DEVICE_ID);
	DMA_preset11(XPAR_AXI_DMA_11_DEVICE_ID);

	DMA_connect_interrupt();

	XAxiDma_IntrEnable(&DMA0, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA1, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA2, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);

	XAxiDma_IntrEnable(&DMA3, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA4, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA5, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);

	DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2 + (27 * 27) * 4 * sizeof(int)*conv2_m);
	DMA_read(&DMA2, 27 * 27 * 4 * sizeof(int));
	DMA_TADDR_setup(&DMA0, IFMAP_BASE_C2 + (31)*(31) * 2 * sizeof(int)*conv2_c);
	DMA_write(&DMA0, (31)*(31) * 2 * sizeof(int));
	DMA_TADDR_setup(&DMA1, FMAP_BASE_C2 + (4 * 2 * 5 * 5 * sizeof(int)*conv2));
	DMA_write(&DMA1, 4 * 2 * 5 * 5 * sizeof(int));

	DMA_RADDR_setup(&DMA5, OFMAP_BASE_C3 + (13 * 13) * 4 * sizeof(int)*conv3_m);
	DMA_read(&DMA5, 13 * 13 * 4 * sizeof(int));
	DMA_TADDR_setup(&DMA3, IFMAP_BASE_C3 + (15)*(15) * 2 * sizeof(int)*conv3_c);
	DMA_write(&DMA3, (15)*(15) * 2 * sizeof(int));
	DMA_TADDR_setup(&DMA4, FMAP_BASE_C3 + (4 * 2 * 3 * 3 * sizeof(int)*conv3));
	DMA_write(&DMA4, 4 * 2 * 3 * 3 * sizeof(int));
}

void pre2(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int tmp = 0;

	it_if = 0;
	for (g = 0; g < group; g++) {
		for (e = 0; e < E; e += tileE) {
			for (f = 0; f < F; f += tileF) {
				for (c = 0; c < C / group; c += tileC) {
					for (i = (c + g * C / group); i < tileC + (c + g * C / group); i++) {
						for (j = e; j < R + tileE - 1 + e; j++) {
							for (k = f; k < S + tileF - 1 + f; k++) {
								tmp = (R + tileE - 1)*(S + tileF - 1)*i + (S + tileF - 1)*j + k;
								Xil_Out32(IFMAP_BASE_C2 + sizeof(int)*it_if++, (int)(ifmap[tmp] / pow(2, 3)));
							}
						}
					}
				}
			}
		}
	}

	it_f = 0;
	for (g = 0; g < group; g++) {
		for (m = 0; m < M / group; m += tileM) {
			for (c = 0; c < C / group; c += tileC) {
				for (i = m; i < tileM + m; i++) {
					for (j = c; j < tileC + c; j++) {
						for (k = 0; k < R*S; k++) {
							tmp = g * C / group * M / group * R*S + C / group * R*S*i + R * S*j + k;
							Xil_Out32(FMAP_BASE_C2 + sizeof(int)*it_f++, (int)(fmap[tmp] * pow(2, 9)));
						}
					}
				}
			}
		}
	}
}
void pre3(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int tileM, int tileC, int tileE, int tileF)
{
	//Declare
	int c = 0, m = 0, f = 0, e = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int tmp = 0;


	//ifmap setting
	it_if = 0;
	for (e = 0; e < E; e += tileE) {
		for (f = 0; f < F; f += tileF) {
			for (c = 0; c < C; c += tileC) {
				for (i = c; i < tileC + c; i++)
				{
					for (j = e; j < R + tileE - 1 + e; j++)
					{
						for (k = f; k < S + tileF - 1 + f; k++)
						{
							tmp = (R + tileE - 1)*(S + tileF - 1)*i + (S + tileF - 1)*j + k;
							Xil_Out32(IFMAP_BASE_C3 + sizeof(int)*it_if++, (int)(ifmap[tmp] / pow(2, 3)));
						}
					}
				}
			}
		}
	}

	//fmap setting
	it_f = 0;
	for (m = 0; m < M; m += tileM)
	{
		for (c = 0; c < C; c += tileC)
		{
			for (i = m; i < tileM + m; i++)
			{
				for (j = c; j < tileC + c; j++)
				{
					for (k = 0; k < R * S; k++)
					{
						tmp = (C)*(R*S)*i + (R*S)*j + k;
						Xil_Out32(FMAP_BASE_C3 + sizeof(int)*it_f++, (int)(fmap[tmp] * pow(2, 9)));
					}
				}
			}
		}
	}
}
void pre4(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int tmp = 0;

	it_if = 0;
	for (g = 0; g < group; g++) {
		for (e = 0; e < E; e += tileE) {
			for (f = 0; f < F; f += tileF) {
				for (c = 0; c < C / group; c += tileC) {
					for (i = (c + g * C / group); i < tileC + (c + g * C / group); i++) {
						for (j = e; j < R + tileE - 1 + e; j++) {
							for (k = f; k < S + tileF - 1 + f; k++) {
								tmp = (R + tileE - 1)*(S + tileF - 1)*i + (S + tileF - 1)*j + k;
								Xil_Out32(IFMAP_BASE_C4 + sizeof(int)*it_if++, (int)(ifmap[tmp] / pow(2, 3)));
							}
						}
					}
				}
			}
		}
	}

	it_f = 0;
	for (g = 0; g < group; g++) {
		for (m = 0; m < M / group; m += tileM) {
			for (c = 0; c < C / group; c += tileC) {
				for (i = m; i < tileM + m; i++) {
					for (j = c; j < tileC + c; j++) {
						for (k = 0; k < R*S; k++) {
							tmp = g * C / group * M / group * R*S + C / group * R*S*i + R * S*j + k;
							Xil_Out32(FMAP_BASE_C4 + sizeof(int)*it_f++, (int)(fmap[tmp] * pow(2, 9)));
						}
					}
				}
			}
		}
	}
}
void pre5(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int tmp = 0;

	it_if = 0;
	for (g = 0; g < group; g++) {
		for (e = 0; e < E; e += tileE) {
			for (f = 0; f < F; f += tileF) {
				for (c = 0; c < C / group; c += tileC) {
					for (i = (c + g * C / group); i < tileC + (c + g * C / group); i++) {
						for (j = e; j < R + tileE - 1 + e; j++) {
							for (k = f; k < S + tileF - 1 + f; k++) {
								tmp = (R + tileE - 1)*(S + tileF - 1)*i + (S + tileF - 1)*j + k;
								Xil_Out32(IFMAP_BASE_C5 + sizeof(int)*it_if++, (int)(ifmap[tmp] / pow(2, 3)));
							}
						}
					}
				}
			}
		}
	}

	it_f = 0;
	for (g = 0; g < group; g++) {
		for (m = 0; m < M / group; m += tileM) {
			for (c = 0; c < C / group; c += tileC) {
				for (i = m; i < tileM + m; i++) {
					for (j = c; j < tileC + c; j++) {
						for (k = 0; k < R*S; k++) {
							tmp = g * C / group * M / group * R*S + C / group * R*S*i + R * S*j + k;
							Xil_Out32(FMAP_BASE_C5 + sizeof(int)*it_f++, (int)(fmap[tmp] * pow(2, 9)));
						}
					}
				}
			}
		}
	}
}

void aft2(float *ofmap,int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_ofo = 0;
	short tmp_ofmap = 0;

	Xil_DCacheInvalidateRange(OFMAP_BASE_C2, (E*F*M) * sizeof(int));

	for (g = 0; g < group; g++)
	{
		for (e = 0; e < E; e += tileE)
		{
			for (f = 0; f < F; f += tileF)
			{
				for (m = 0; m < M / group; m += tileM)
				{
					for (i = (m + g * M / group); i < tileM + (m + g * M / group); i++)
					{
						for (j = e; j < tileE + e; j++)
						{
							for (k = f; k < tileF + f; k++)
							{
								tmp_ofmap = Xil_In16(OFMAP_BASE_C2 + sizeof(int)*(it_ofo));
								ofmap[i*E*F + j * F + k] = (float)(tmp_ofmap / pow(2, 6));
								it_ofo++;
							}
						}
					}
				}
			}
		}
	}
}
void aft3(float *ofmap,int M, int C, int F, int E, int R, int S, int H, int W, int tileM ,int tileC , int tileE, int tileF)
{
	//Declare
	int c = 0, m = 0, f = 0, e = 0;
	int i = 0, j = 0, k = 0;
	int it_ofo = 0;
	short oftmp = 0;

	Xil_DCacheInvalidateRange(OFMAP_BASE_C3, (tileE*tileF*M) * sizeof(int));

	for (e = 0; e < E; e += tileE)
	{
		for (f = 0; f < F; f += tileF)
		{
			for (m = 0; m < M; m += tileM)
			{
				for (i = m; i < tileM + m; i++)
				{
					for (j = e; j < tileE + e; j++)
					{
						for (k = f; k < tileF + f; k++)
						{
							oftmp = Xil_In16(OFMAP_BASE_C3 + sizeof(int)*(it_ofo));
							ofmap[i*E *F + j * F + k] = (float)(oftmp / pow(2, 6));
							it_ofo++;
						}
					}
				}
			}
		}
	}
}
void aft4(float *ofmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_ofo = 0;
	short tmp_ofmap = 0;

	Xil_DCacheInvalidateRange(OFMAP_BASE_C4, (E*F*M) * sizeof(int));

	for (g = 0; g < group; g++)
	{
		for (e = 0; e < E; e += tileE)
		{
			for (f = 0; f < F; f += tileF)
			{
				for (m = 0; m < M / group; m += tileM)
				{
					for (i = (m + g * M / group); i < tileM + (m + g * M / group); i++)
					{
						for (j = e; j < tileE + e; j++)
						{
							for (k = f; k < tileF + f; k++)
							{
								tmp_ofmap = Xil_In16(OFMAP_BASE_C4 + sizeof(int)*(it_ofo));
								ofmap[i*E*F + j * F + k] = (float)(tmp_ofmap / pow(2, 6));
								it_ofo++;
							}
						}
					}
				}
			}
		}
	}
}
void aft5(float *ofmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_ofo = 0;
	short tmp_ofmap = 0;

	Xil_DCacheInvalidateRange(OFMAP_BASE_C5, (E*F*M) * sizeof(int));

	for (g = 0; g < group; g++)
	{
		for (e = 0; e < E; e += tileE)
		{
			for (f = 0; f < F; f += tileF)
			{
				for (m = 0; m < M / group; m += tileM)
				{
					for (i = (m + g * M / group); i < tileM + (m + g * M / group); i++)
					{
						for (j = e; j < tileE + e; j++)
						{
							for (k = f; k < tileF + f; k++)
							{
								tmp_ofmap = Xil_In16(OFMAP_BASE_C5 + sizeof(int)*(it_ofo));
								ofmap[i*E*F + j * F + k] = (float)(tmp_ofmap / pow(2, 6));
								it_ofo++;
							}
						}
					}
				}
			}
		}
	}
}

void Reset_Isr()
{
	dma0 = 0;
	dma1 = 0;
	dma2 = 0;
	conv2 = 0;
	conv2_c = 0;
	conv2_m = 0;
	conv2_g = 0;
	/////////////////////////////////////// Convolution 3 Variable
	dma3 = 0;
	dma4 = 0;
	dma5 = 0;
	conv3 = 0;
	conv3_c = 0;
	conv3_m = 0;
	/////////////////////////////////////// Convolution 4 Variable
	dma6 = 0;
	dma7 = 0;
	dma8 = 0;
	conv4 = 0;
	conv4_c = 0;
	conv4_m = 0;
	conv4_g = 0;
	/////////////////////////////////////// Convolution 5 Variable
	dma9 = 0;
	dma10 = 0;
	dma11 = 0;
	conv5 = 0;
	conv5_c = 0;
	conv5_m = 0;
	conv5_g = 0;
}

void ref2(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int it_ofo = 0, it_ofo2 = 0;
	int tmp = 0;

	  	it_if=0;
	  	it_f=0;
	  	it_ofo=0;
	  	it_ofo2=0;

	  	for (g = 0; g < group; g++)
	  	{
			for (e = 0; e < E; e += tileE)
			{
				for (f = 0; f < F; f += tileF)
				{
					for (m = 0 + g*M/group; m < M/group + g*M/group; m += tileM)
					{
						if (g == 0){
							if(m > 0){
								DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
								DMA_read(&DMA2, tileM * tileE * tileF * sizeof(int));
							}
						}
						else{
							if(m > g*M/group){
								DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
								DMA_read(&DMA2, tileM * tileE * tileF * sizeof(int));
							}
						}

						if (g == 0)
							it_if = 0;
						else
							it_if = (C/group)/tileC;

						for (c = 0 + g*C/group; c < C/group + g*C/group; c += tileC)
						{

							DMA_TADDR_setup(&DMA0, IFMAP_BASE_C2+(tileE+R-1)*(tileF+S-1)*tileC*sizeof(int)*it_if);
							DMA_write(&DMA0, (tileE+R-1)*(tileF+S-1)*tileC*sizeof(int));

							DMA_TADDR_setup(&DMA1, FMAP_BASE_C2 +(tileM*tileC*R*S*sizeof(int)*it_f));
							DMA_write(&DMA1, tileM*tileC*R*S*sizeof(int));

							while ((XAxiDma_Busy(&DMA0, XAXIDMA_DMA_TO_DEVICE)));
							while ((XAxiDma_Busy(&DMA1, XAXIDMA_DMA_TO_DEVICE)));

							it_if++;
							it_f++;
						}

						if (g == 0){
							if(m > 0)
							{
								while ((XAxiDma_Busy(&DMA2, XAXIDMA_DEVICE_TO_DMA)));
								it_ofo2++;
							}
						}
						else{
							if(m > g*M/group)
							{
								while ((XAxiDma_Busy(&DMA2, XAXIDMA_DEVICE_TO_DMA)));
								it_ofo2++;
							}
						}
					}

					DMA_RADDR_setup(&DMA2, OFMAP_BASE_C2+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
					DMA_read(&DMA2, (tileE*tileF)*tileM*sizeof(int));
					while ((XAxiDma_Busy(&DMA2, XAXIDMA_DEVICE_TO_DMA)));
					it_ofo2++;
				}
			}
		}
}
void ref3(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int tileM, int tileC, int tileE, int tileF)
{
	//Declare
	int c = 0, m = 0, f = 0, e = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0;
	int tmp = 0;
	int it_ofo2 = 0;

	for (e = 0; e < E; e += tileE)
		{
			for (f = 0; f < F; f += tileF)
			{
				for (m = 0; m < M; m += tileM)
				{
					DMA_RADDR_setup(&DMA5, OFMAP_BASE_C3+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
					DMA_read(&DMA5, tileM * tileE * tileF * sizeof(int));
					it_if = 0;
					for (c = 0; c < C; c += tileC)
					{
						DMA_TADDR_setup(&DMA3, IFMAP_BASE_C3+(tileE+R-1)*(tileF+S-1)*tileC*sizeof(int)*it_if);
						DMA_write(&DMA3, (tileE+R-1)*(tileF+S-1)*tileC*sizeof(int));
						DMA_TADDR_setup(&DMA4, FMAP_BASE_C3+(tileM*tileC*R*S*sizeof(int)*it_f));
						DMA_write(&DMA4, tileM*tileC*R*S*sizeof(int));

						while ((XAxiDma_Busy(&DMA3, XAXIDMA_DMA_TO_DEVICE)));
						while ((XAxiDma_Busy(&DMA4, XAXIDMA_DMA_TO_DEVICE)));

						it_if++;
						it_f++;
					}

					if(m>0)
					{
						while ((XAxiDma_Busy(&DMA5, XAXIDMA_DEVICE_TO_DMA)));
						it_ofo2++;
					}

				}

				DMA_RADDR_setup(&DMA5, OFMAP_BASE_C3+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
				DMA_read(&DMA5, (tileE*tileF)*tileM*sizeof(int));
				while ((XAxiDma_Busy(&DMA2, XAXIDMA_DEVICE_TO_DMA)));
				it_ofo2++;

			}
		}

}
void ref4(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
		int i = 0, j = 0, k = 0;
		int it_if = 0, it_f = 0;
		int it_ofo = 0, it_ofo2 = 0;
		int tmp = 0;

		  	it_if=0;
		  	it_f=0;
		  	it_ofo=0;
		  	it_ofo2=0;

		  	for (g = 0; g < group; g++)
		  	{
				for (e = 0; e < E; e += tileE)
				{
					for (f = 0; f < F; f += tileF)
					{
						for (m = 0 + g*M/group; m < M/group + g*M/group; m += tileM)
						{
							if (g == 0){
								if(m > 0){
									DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
									DMA_read(&DMA8, tileM * tileE * tileF * sizeof(int));
								}
							}
							else{
								if(m > g*M/group){
									DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
									DMA_read(&DMA8, tileM * tileE * tileF * sizeof(int));
								}
							}

							if (g == 0)
								it_if = 0;
							else
								it_if = (C/group)/tileC;

							for (c = 0 + g*C/group; c < C/group + g*C/group; c += tileC)
							{

								DMA_TADDR_setup(&DMA6, IFMAP_BASE_C4+(tileE+R-1)*(tileF+S-1)*tileC*sizeof(int)*it_if);
								DMA_write(&DMA6, (tileE+R-1)*(tileF+S-1)*tileC*sizeof(int));

								DMA_TADDR_setup(&DMA7, FMAP_BASE_C4 +(tileM*tileC*R*S*sizeof(int)*it_f));
								DMA_write(&DMA7, tileM*tileC*R*S*sizeof(int));

								while ((XAxiDma_Busy(&DMA6, XAXIDMA_DMA_TO_DEVICE)));
								while ((XAxiDma_Busy(&DMA7, XAXIDMA_DMA_TO_DEVICE)));

								it_if++;
								it_f++;
							}

							if (g == 0){
								if(m > 0)
								{
									while ((XAxiDma_Busy(&DMA8, XAXIDMA_DEVICE_TO_DMA)));
									it_ofo2++;
								}
							}
							else{
								if(m > g*M/group)
								{
									while ((XAxiDma_Busy(&DMA8, XAXIDMA_DEVICE_TO_DMA)));
									it_ofo2++;
								}
							}
						}

						DMA_RADDR_setup(&DMA8, OFMAP_BASE_C4+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
						DMA_read(&DMA8, (tileE*tileF)*tileM*sizeof(int));
						while ((XAxiDma_Busy(&DMA8, XAXIDMA_DEVICE_TO_DMA)));
						it_ofo2++;
					}
				}
			}

}
void ref5(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	int c = 0, m = 0, f = 0, e = 0, g = 0;
			int i = 0, j = 0, k = 0;
			int it_if = 0, it_f = 0;
			int it_ofo = 0, it_ofo2 = 0;
			int tmp = 0;

			  	it_if=0;
			  	it_f=0;
			  	it_ofo=0;
			  	it_ofo2=0;

			  	for (g = 0; g < group; g++)
			  	{
					for (e = 0; e < E; e += tileE)
					{
						for (f = 0; f < F; f += tileF)
						{
							for (m = 0 + g*M/group; m < M/group + g*M/group; m += tileM)
							{
								if (g == 0){
									if(m > 0){
										DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
										DMA_read(&DMA11, tileM * tileE * tileF * sizeof(int));
									}
								}
								else{
									if(m > g*M/group){
										DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
										DMA_read(&DMA11, tileM * tileE * tileF * sizeof(int));
									}
								}

								if (g == 0)
									it_if = 0;
								else
									it_if = (C/group)/tileC;

								for (c = 0 + g*C/group; c < C/group + g*C/group; c += tileC)
								{

									DMA_TADDR_setup(&DMA9, IFMAP_BASE_C5+(tileE+R-1)*(tileF+S-1)*tileC*sizeof(int)*it_if);
									DMA_write(&DMA9, (tileE+R-1)*(tileF+S-1)*tileC*sizeof(int));

									DMA_TADDR_setup(&DMA10, FMAP_BASE_C5 +(tileM*tileC*R*S*sizeof(int)*it_f));
									DMA_write(&DMA10, tileM*tileC*R*S*sizeof(int));

									while ((XAxiDma_Busy(&DMA9, XAXIDMA_DMA_TO_DEVICE)));
									while ((XAxiDma_Busy(&DMA10, XAXIDMA_DMA_TO_DEVICE)));

									it_if++;
									it_f++;
								}

								if (g == 0){
									if(m > 0)
									{
										while ((XAxiDma_Busy(&DMA11, XAXIDMA_DEVICE_TO_DMA)));
										it_ofo2++;
									}
								}
								else{
									if(m > g*M/group)
									{
										while ((XAxiDma_Busy(&DMA11, XAXIDMA_DEVICE_TO_DMA)));
										it_ofo2++;
									}
								}
							}

							DMA_RADDR_setup(&DMA11, OFMAP_BASE_C5+(tileE*tileF)*tileM*sizeof(int)*it_ofo2);
							DMA_read(&DMA11, (tileE*tileF)*tileM*sizeof(int));
							while ((XAxiDma_Busy(&DMA11, XAXIDMA_DEVICE_TO_DMA)));
							it_ofo2++;
						}
					}
				}
}
