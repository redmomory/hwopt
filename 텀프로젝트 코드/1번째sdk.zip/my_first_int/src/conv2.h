/******************************************************************************
Copyright (c) 2017 SoC Design Laboratory, Konkuk University, South Korea
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met: redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer;
redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution;
neither the name of the copyright holders nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Authors: Jooho Wang (joohowang@konkuk.ac.kr)
Revision History
2018.11.14: Started by Jooho Wang
2019.05.27: Extended by Sunwoo Kim (AlexNet)
*******************************************************************************/

#include "xparameters.h"
#include "xparameters_ps.h"
#include "platform.h"
#include "xaxidma.h"
#include "xscugic.h"	 // Processor interrupt controller device driver

XAxiDma DMA0;
XAxiDma DMA1;
XAxiDma DMA2;

/* Interrupt Controller Instance */
XScuGic scugic;

/////////////////////////////////////// Convolution 2 Variable
volatile int dma0 = 0;
volatile int dma1 = 0;
volatile int dma2 = 0;
volatile int conv2 = 0;
volatile int conv2_c = 0;
volatile int conv2_m = 0;
volatile int conv2_g = 0;

static void DMA0_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		dma0++;
		if (conv2_c == 47 && conv2_m == 62)
		{
			conv2_m++;
			DMA_RADDR_setup2(&DMA2, OFMAPOUT_BASE + 27 * 27 * 4 * sizeof(int)*(conv2_m));
			DMA_read2(&DMA2, 27 * 27 * 4 * sizeof(int));
			dma2 = 1;
			xil_printf("conv2_End\n\r");
		}
		else
		{
			if (dma0 == dma1) // �Ѵ� interrupt�� �߻��������� �ǹ�
			{
				conv2++;
				conv2_c = conv2_g * 24 + (conv2 % 24);
				if (conv2_c == 0 || conv2_c == 24)
				{
					DMA_RADDR_setup2(&DMA2, OFMAPOUT_BASE + 27 * 27 * 4 * sizeof(int)*(conv2_m));
					DMA_read2(&DMA2, 27 * 27 * 4 * sizeof(int));
					conv2_m++;
					if (conv2_m == 30)
					{
						conv2_g = 1;
					}
				}
				DMA_TADDR_setup2(&DMA0, IFMAP_BASE + 31 * 31 * 2 * sizeof(int)*conv2_c);
				DMA_write2(&DMA0, 31 * 31 * 2 * sizeof(int));
				DMA_TADDR_setup2(&DMA1, FMAP_BASE + (4 * 2 * 5 * 5 * sizeof(int)*conv2));
				DMA_write2(&DMA1, 4 * 2 * 5 * 5 * sizeof(int));
			}
		}
	}
}
static void DMA1_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DMA_TO_DEVICE);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) { //Send Done Handler Routine
		dma1++;
		if (conv2_c == 47 && conv2_m == 62)
		{
			conv2_m++;
			DMA_RADDR_setup2(&DMA2, OFMAPOUT_BASE + 27 * 27 * 4 * sizeof(int)*(conv2_m));
			DMA_read2(&DMA2, 27 * 27 * 4 * sizeof(int));
			dma2 = 1;
			xil_printf("conv2_End\n\r");
		}
		else
		{
			if (dma0 == dma1) // �Ѵ� interrupt�� �߻��������� �ǹ�
			{
				conv2++;
				conv2_c = conv2_g * 24 + (conv2 % 24);
				if (conv2_c == 0 || conv2_c == 24)
				{
					DMA_RADDR_setup2(&DMA2, OFMAPOUT_BASE + 27 * 27 * 4 * sizeof(int)*(conv2_m));
					DMA_read2(&DMA2, 27 * 27 * 4 * sizeof(int));
					conv2_m++;
					if (conv2_m == 31)
					{
						conv2_g = 1;
					}
				}
				DMA_TADDR_setup2(&DMA0, IFMAP_BASE + 31 * 31 * 2 * sizeof(int)*conv2_c);
				DMA_write2(&DMA0, 31 * 31 * 2 * sizeof(int));
				DMA_TADDR_setup2(&DMA1, FMAP_BASE + (4 * 2 * 5 * 5 * sizeof(int)*conv2));
				DMA_write2(&DMA1, 4 * 2 * 5 * 5 * sizeof(int));
			}
		}
	}
}
static void DMA2_isr(void* Callback)
{
	u32 IrqStatus;
	XAxiDma *AxiDmaInst = (XAxiDma *)Callback;
	/* Read pending interrupts */
	IrqStatus = XAxiDma_IntrGetIrq(AxiDmaInst, XAXIDMA_DEVICE_TO_DMA);
	/* Acknowledge pending interrupts */
	XAxiDma_IntrAckIrq(AxiDmaInst, IrqStatus, XAXIDMA_DEVICE_TO_DMA);
	if (!(IrqStatus & XAXIDMA_IRQ_ALL_MASK)) {
		return;
	}
	if ((IrqStatus & XAXIDMA_IRQ_IOC_MASK)) {
		if (conv2_c == 47 && conv2_m == 63)
		{
			xil_printf("Lable2 End! \n\r");
			dma2 = 1;
		}
	}
}

static int DMA_connect_interrupt2(void)
{
	//This functions sets up the interrupt on the Arm
	int status;
	XScuGic_Config *scugic_cfg = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);
	if (scugic_cfg == NULL) {
		xil_printf("Interrupt Configuration Lookup Failed\n\r");
		return XST_FAILURE;
	}

	status = XScuGic_CfgInitialize(&scugic, scugic_cfg, scugic_cfg->CpuBaseAddress);
	if (status != XST_SUCCESS) {
		xil_printf("ScuGic Initialize Failed\n\r");
		return status;
	}

	status = XScuGic_SelfTest(&scugic);
	if (status != XST_SUCCESS) {
		xil_printf("ScuGic selfTest Failed\n\r");
		return status;
	}
	//	XScuGic_SetPriorityTriggerType(&scugic, XPAR_FABRIC_AXI_DMA_3_MM2S_INTROUT_INTR, 0xA0, 0x3);
	//	XScuGic_SetPriorityTriggerType(&scugic, XPAR_FABRIC_AXI_DMA_4_MM2S_INTROUT_INTR, 0xA4, 0x3);
	//	XScuGic_SetPriorityTriggerType(&scugic, XPAR_FABRIC_AXI_DMA_5_S2MM_INTROUT_INTR, 0xA8, 0x3);

	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA0_isr, &DMA0);
	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR, (Xil_InterruptHandler)DMA1_isr, &DMA1);
	XScuGic_Connect(&scugic, XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR, (Xil_InterruptHandler)DMA2_isr, &DMA2);
	/*
	if (status != XST_SUCCESS) {
		xil_printf("Interrupt Connect Failed \n\r");
		return status;
	}*/
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR);
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR);
	XScuGic_Enable(&scugic, XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR);

	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler, &scugic);
	Xil_ExceptionEnable();
	return XST_SUCCESS;
}
int initializeAXIDma0() {
	XAxiDma_Config *CfgPtr;
	int Status;
	CfgPtr = XAxiDma_LookupConfig(XPAR_AXI_DMA_0_DEVICE_ID);
	Status = XAxiDma_CfgInitialize(&DMA0, CfgPtr);
	return 0;
}
int initializeAXIDma1() {
	XAxiDma_Config *CfgPtr;
	int Status;
	CfgPtr = XAxiDma_LookupConfig(XPAR_AXI_DMA_1_DEVICE_ID);
	Status = XAxiDma_CfgInitialize(&DMA1, CfgPtr);
	return 0;
}
int initializeAXIDma2() {
	XAxiDma_Config *CfgPtr;
	int Status;
	CfgPtr = XAxiDma_LookupConfig(XPAR_AXI_DMA_2_DEVICE_ID);
	Status = XAxiDma_CfgInitialize(&DMA2, CfgPtr);
	return 0;
}
void DMA_TADDR_setup2(XAxiDma *Set_DMA, int SrcAddr) {
	int RingIndex = 0;

	XAxiDma_WriteReg(Set_DMA->TxBdRing.ChanBase,
		XAXIDMA_SRCADDR_OFFSET, (u32)SrcAddr);

	XAxiDma_WriteReg(Set_DMA->TxBdRing.ChanBase,
		XAXIDMA_CR_OFFSET,
		XAxiDma_ReadReg(Set_DMA->TxBdRing.ChanBase, XAXIDMA_CR_OFFSET) | XAXIDMA_CR_RUNSTOP_MASK);

}
void DMA_RADDR_setup2(XAxiDma *Set_DMA, int DestAddr) {
	int RingIndex = 0;

	XAxiDma_WriteReg(Set_DMA->RxBdRing[RingIndex].ChanBase,
		XAXIDMA_DESTADDR_OFFSET, (u32)DestAddr);

	XAxiDma_WriteReg(Set_DMA->RxBdRing[RingIndex].ChanBase,
		XAXIDMA_CR_OFFSET,
		XAxiDma_ReadReg(Set_DMA->RxBdRing[RingIndex].ChanBase,
			XAXIDMA_CR_OFFSET) | XAXIDMA_CR_RUNSTOP_MASK);
}
void DMA_write2(XAxiDma *Set_DMA, int Len) {
	int RingIndex = 0;
	XAxiDma_WriteReg(Set_DMA->TxBdRing.ChanBase,
		XAXIDMA_BUFFLEN_OFFSET, Len);
}
void DMA_read2(XAxiDma *Set_DMA, int Len) {
	int RingIndex = 0;

	XAxiDma_WriteReg(Set_DMA->RxBdRing[RingIndex].ChanBase,
		XAXIDMA_BUFFLEN_OFFSET, Len);
}

void convolution2(float *ofmap, float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF)
{
	//Declare
	int c = 0, m = 0, f = 0, e = 0, g = 0;
	int i = 0, j = 0, k = 0;
	int it_if = 0, it_f = 0, it_ofo = 0, it_ofo2 = 0;
	int tmp = 0;
	short tmp_ofmap = 0;

	////////////// data set at DDR ///////////////
	it_if = 0;
	for (g = 0; g < group; g++) {
		for (e = 0; e < E; e += tileE) {
			for (f = 0; f < F; f += tileF) {
				for (c = 0; c < C / group; c += tileC) {
					for (i = (c + g * C / group); i < tileC + (c + g * C / group); i++) {
						for (j = e; j < R + tileE - 1 + e; j++) {
							for (k = f; k < S + tileF - 1 + f; k++) {
								tmp = (R + tileE - 1)*(S + tileF - 1)*i + (S + tileF - 1)*j + k;
								Xil_Out32(IFMAP_BASE + sizeof(int)*it_if++, (int)(ifmap[tmp] / pow(2, 3)));
							}
						}
					}
				}
			}
		}
	}

	it_f = 0;
	for (g = 0; g < group; g++) {
		for (m = 0; m < M / group; m += tileM) {
			for (c = 0; c < C / group; c += tileC) {
				for (i = m; i < tileM + m; i++) {
					for (j = c; j < tileC + c; j++) {
						for (k = 0; k < R*S; k++) {
							tmp = g * C / group * M / group * R*S + C / group * R*S*i + R * S*j + k;
							Xil_Out32(FMAP_BASE + sizeof(int)*it_f++, (int)(fmap[tmp] * pow(2, 9)));
						}
					}
				}
			}
		}
	}

	///////////// D cacheFulsh //////////////

	Xil_DCacheFlushRange(IFMAP_BASE, sizeof(int)*H*W*C);
	Xil_DCacheFlushRange(FMAP_BASE, sizeof(int)*R*S*C*M);

	//////////// Data Transfer DDR to BRAM //////////////
	initializeAXIDma0();
	initializeAXIDma1();
	initializeAXIDma2();
	DMA_connect_interrupt2();
	XAxiDma_IntrEnable(&DMA0, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA1, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrEnable(&DMA2, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);

	DMA_RADDR_setup2(&DMA2, OFMAPOUT_BASE + (27 * 27) * 4 * sizeof(int)*conv2_m);
	DMA_read2(&DMA2, 27 * 27 * 4 * sizeof(int));
	DMA_TADDR_setup2(&DMA0, IFMAP_BASE + (31)*(31) * 2 * sizeof(int)*conv2_c);
	DMA_write2(&DMA0, (31)*(31) * 2 * sizeof(int));
	DMA_TADDR_setup2(&DMA1, FMAP_BASE + (4 * 2 * 5 * 5 * sizeof(int)*conv2));
	DMA_write2(&DMA1, 4 * 2 * 5 * 5 * sizeof(int));
	while (1)
	{
		if (dma2 == 1)
		{
			dma0 = 0;
			dma1 = 0;
			dma2 = 0;
			conv2 = 0;
			conv2_c = 0;
			conv2_m = 0;
			conv2_g = 0;
			xil_printf("Lable 2 Success with interrupt \n\r");
			break;
		}
	}
	XAxiDma_IntrDisable(&DMA0, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrDisable(&DMA1, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DMA_TO_DEVICE);
	XAxiDma_IntrDisable(&DMA2, (XAXIDMA_IRQ_IOC_MASK | XAXIDMA_IRQ_ERROR_MASK), XAXIDMA_DEVICE_TO_DMA);
	////////////// Data Transfer BRAM to DDR /////////////////

	Xil_DCacheInvalidateRange(OFMAPOUT_BASE, (E*F*M) * sizeof(int));

	it_ofo = 0;

	for (g = 0; g < group; g++)
	{
		for (e = 0; e < E; e += tileE)
		{
			for (f = 0; f < F; f += tileF)
			{
				for (m = 0; m < M / group; m += tileM)
				{
					for (i = (m + g * M / group); i < tileM + (m + g * M / group); i++)
					{
						for (j = e; j < tileE + e; j++)
						{
							for (k = f; k < tileF + f; k++)
							{
								tmp_ofmap = Xil_In16(OFMAPOUT_BASE + sizeof(int)*(it_ofo));
								ofmap[i*E*F + j * F + k] = (float)(tmp_ofmap / pow(2, 6));
								it_ofo++;
							}
						}
					}
				}
			}
		}
	}
}
