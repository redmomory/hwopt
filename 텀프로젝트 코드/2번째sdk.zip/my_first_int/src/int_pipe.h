


extern int Layer2CFlag();
extern int Layer3CFlag();
extern int Layer4CFlag();
extern int Layer5CFlag();
static int DMA_connect_interrupt(void);

void Start_ISR();
void pre2(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void pre3(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int tileM, int tileC, int tileE, int tileF);
void pre4(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void pre5(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void aft2(float *ofmap,int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void aft3(float *ofmap,int M, int C, int F, int E, int R, int S, int H, int W, int tileM ,int tileC , int tileE, int tileF);
void aft4(float *ofmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);

void aft5(float *ofmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void Reset_Isr();
void ref2(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void ref3(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int tileM, int tileC, int tileE, int tileF);
void ref4(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);
void ref5(float *ifmap, float *fmap, int M, int C, int F, int E, int R, int S, int H, int W, int group, int tileM, int tileC, int tileE, int tileF);









